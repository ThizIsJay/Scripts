#! /usr/bin/env bash

mkdir -p $HOME/.local/bin
mv ./update $HOME/.local/bin/update
echo "Installatie compleet!"
echo "Update script bevind zich in $HOME/.local/bin"
